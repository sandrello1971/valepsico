import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const ApproachSection = () => {
  return (
    <section className="section-padding bg-muted/20">
      <div className="max-w-7xl mx-auto container-padding">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-8">
            Un Incontro Da Persona A Persona: Il Mio Approccio Terapeutico
          </h2>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Generated image placeholder */}
          <div className="relative">
            <div className="aspect-video bg-gradient-primary rounded-2xl shadow-elegant flex items-center justify-center">
              <div className="text-center text-white">
                <div className="w-16 h-16 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <p className="text-sm opacity-90">Immagine dell'approccio terapeutico</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <div>
              <p className="text-lg text-foreground">
                Ogni terapeuta ha un modo di lavorare diverso. Il mio si basa sull'<strong>Approccio Centrato sulla Persona</strong> (ACP), sviluppato da <strong>Carl Rogers</strong> nel 1942.
              </p>
            </div>
            
            <div>
              <p className="text-lg text-foreground">
                Al centro del mio lavoro ci sei <strong>tu</strong>: il tuo benessere e la tua crescita personale. Ti aprirò le porte ad un luogo sicuro e accogliente, dove potrai esplorare liberamente pensieri, emozioni e vissuti più profondi.
              </p>
            </div>
            
            <div>
              <p className="text-lg text-foreground">
                Credo fermamente nelle tue <strong>risorse</strong>: hai dentro di te la forza per affrontare le sfide della vita. Il mio ruolo è accompagnarti in un percorso di auto-esplorazione, aiutandoti a coltivare una maggiore <strong>consapevolezza</strong> di te stesso e dei tuoi talenti.
              </p>
            </div>

            <div>
              <p className="text-lg text-foreground">
                Nel nostro percorso insieme, <strong>sei tu il capitano della tua nave</strong>. Il viaggio procede alla tua velocità. Prendiamoci il tempo per fare soste quando serve, ammirare il paesaggio e riflettere sui prossimi passi.
              </p>
            </div>

            <div>
              <p className="text-lg text-foreground font-medium italic">
                Il nostro obiettivo comune? <strong>Esplorare i sentieri</strong> che ti porteranno verso una maggiore realizzazione personale e un profondo benessere emotivo.
              </p>
            </div>

            <div className="pt-4">
              <Button asChild className="btn-primary">
                <Link to="/contatti">
                  Sei pronto a iniziare questo viaggio?
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ApproachSection;
