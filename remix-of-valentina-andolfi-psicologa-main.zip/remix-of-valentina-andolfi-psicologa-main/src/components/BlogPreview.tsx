import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const BlogPreview = () => {
  return (
    <section className="section-padding bg-muted/20" aria-labelledby="blog-heading">
      <div className="max-w-7xl mx-auto container-padding">
        <div className="text-center mb-16">
          <h2 id="blog-heading" className="text-3xl lg:text-4xl font-bold text-foreground mb-6">
            Il mio blog: ascolto, racconto e intreccio racconti di vita
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Ho molte cose da dirti, riflessioni e curiosità da condividere.
          </p>
          <p className="text-foreground font-bold text-lg">
            Segui il mio blog per scoprirle.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {/* Blog Post 1 */}
          <Card className="overflow-hidden shadow-elegant hover:shadow-2xl transition-all duration-300 group">
            <div className="aspect-video bg-gradient-primary flex items-center justify-center" aria-hidden="true">
              <div className="text-center text-white">
                <div className="w-16 h-16 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <p className="text-sm opacity-90">Immagine dell'articolo</p>
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-accent transition-colors">
                Christmas Blues: Superare la Malinconia Natale e Trovare la Serenità
              </h3>
              <p className="text-muted-foreground text-sm mb-4">
                Scopri come affrontare la tristezza delle festività e ritrovare il benessere emotivo durante il periodo natalizio.
              </p>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <time dateTime="2024-12-15">15 Dicembre 2024</time>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" aria-hidden="true" />
              </div>
            </div>
          </Card>

          {/* Blog Post 2 */}
          <Card className="overflow-hidden shadow-elegant hover:shadow-2xl transition-all duration-300 group">
            <div className="aspect-video bg-gradient-primary flex items-center justify-center" aria-hidden="true">
              <div className="text-center text-white">
                <div className="w-16 h-16 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                    <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" />
                  </svg>
                </div>
                <p className="text-sm opacity-90">Immagine dell'articolo</p>
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-accent transition-colors">
                L'Importanza dell'Autocompassione nel Percorso di Crescita
              </h3>
              <p className="text-muted-foreground text-sm mb-4">
                Come sviluppare un rapporto più gentile con se stessi per favorire il benessere psicologico.
              </p>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <time dateTime="2024-12-08">8 Dicembre 2024</time>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" aria-hidden="true" />
              </div>
            </div>
          </Card>

          {/* Blog Post 3 */}
          <Card className="overflow-hidden shadow-elegant hover:shadow-2xl transition-all duration-300 group">
            <div className="aspect-video bg-gradient-primary flex items-center justify-center" aria-hidden="true">
              <div className="text-center text-white">
                <div className="w-16 h-16 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                    <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="text-sm opacity-90">Immagine dell'articolo</p>
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-accent transition-colors">
                Gestire l'Ansia: Strategie Pratiche per il Quotidiano
              </h3>
              <p className="text-muted-foreground text-sm mb-4">
                Tecniche efficaci per riconoscere e gestire l'ansia nelle situazioni di tutti i giorni.
              </p>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <time dateTime="2024-12-01">1 Dicembre 2024</time>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" aria-hidden="true" />
              </div>
            </div>
          </Card>
        </div>
        
        <div className="text-center">
          <Button asChild className="btn-primary">
            <Link to="/blog">
              Leggi tutti gli articoli
              <ArrowRight className="ml-2 h-5 w-5" aria-hidden="true" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default BlogPreview;
