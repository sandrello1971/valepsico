import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import valentinaPhoto from '@/assets/valentina-photo.png';

const Hero = () => {
  return (
    <section className="bg-gradient-hero min-h-screen flex items-center section-padding">
      <div className="max-w-7xl mx-auto container-padding">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Hero Content */}
          <div className="animate-fade-up">
            <h1 className="mb-8">
              <span className="block text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-foreground mb-4">
                Valentina Rita Andolfi
              </span>
              <span className="block text-3xl md:text-4xl lg:text-5xl font-serif text-foreground mb-2">
                Psicologa, Ricercatrice,<br />Psicoterapeuta
              </span>
              <span className="block text-2xl md:text-3xl font-serif font-bold text-foreground italic">
                a Milano e Online
              </span>
            </h1>
            
            <div className="space-y-6 text-xl leading-relaxed text-foreground mb-8 max-w-2xl">
              <p className="text-2xl font-medium">
                Benvenuto in uno spazio dedicato al <strong>benessere</strong>, alla <strong>cura</strong> e alla <strong>crescita personale</strong>.
              </p>
              
              <p className="text-xl">
                Sono una professionista che può aiutarti a <strong>capire meglio te stesso</strong>, superare le sfide della vita, risolvere problemi relazionali o di autostima, affrontare delle perdite o dei cambiamenti, o puoi iniziare con me un percorso di <strong>crescita personale</strong> per fare fiorire le tue risorse.
              </p>
              
              <p className="text-xl">
                Sono in grado di accoglierti in uno <strong>spazio sereno</strong> e accogliente dove potrai sentirti libero di esplorare te stesso, i tuoi pensieri e sentimenti più intimi, <strong>senza giudizio</strong>.
              </p>
              
              <p className="text-xl">
                So che affrontare le sfide della vita può essere difficile, ma in questo percorso <strong>non sei solo</strong>. Scopriremo cosa ti affatica e svilupperemo le risorse per superare ogni ostacolo.
              </p>

              <p className="text-xl font-medium">
                <strong>Costruiremo un equipaggio di risorse</strong> per raggiungere ciò che vuoi davvero. Progetteremo insieme un percorso verso una vita più felice, equilibrata e significativa.
              </p>
              
              <p className="text-xl">
                Fare il primo passo verso il cambiamento richiede <strong>coraggio</strong> e tu ne hai dimostrato, arrivando fin qui. Prendi un respiro e ascoltati nel profondo: senti il bisogno di un <strong>cambiamento</strong>?
              </p>

              <p className="text-xl font-bold italic text-foreground">
                Io sono pronta ad accompagnarti in questo viaggio!
              </p>
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              <Button asChild size="lg" className="btn-primary text-lg px-8 py-4">
                <Link to="/contatti">
                  Contattami
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="btn-outline text-lg px-8 py-4">
                <Link to="/servizi">
                  Scopri cosa posso fare per te
                </Link>
              </Button>
            </div>
          </div>

          {/* Hero Image */}
          <div className="animate-fade-up lg:pl-8">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-primary rounded-3xl transform rotate-3"></div>
              <img
                src={valentinaPhoto}
                alt="Valentina Rita Andolfi - Psicologa e Psicoterapeuta"
                className="relative rounded-3xl shadow-2xl w-full max-w-md mx-auto lg:max-w-none"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
