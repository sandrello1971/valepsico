import Hero from "@/components/Hero";
import IntroSection from "@/components/IntroSection";
import ApproachSection from "@/components/ApproachSection";
import PersonalitySection from "@/components/PersonalitySection";
import BlogPreview from "@/components/BlogPreview";
import SEOHead from "@/components/SEOHead";

const localBusinessJsonLd = {
  "@context": "https://schema.org",
  "@type": ["LocalBusiness", "MedicalBusiness"],
  "name": "Dott.ssa Valentina Rita Andolfi - Psicologa e Psicoterapeuta",
  "description": "Psicologa e Psicoterapeuta a Milano e Online. Consulenza individuale, di coppia e per giovani adulti con approccio centrato sulla persona.",
  "url": "https://valentina-andolfi.com",
  "telephone": "+39 123 456 7890",
  "email": "info@valentina-andolfi.com",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Milano",
    "addressRegion": "Lombardia",
    "addressCountry": "IT"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "45.4642",
    "longitude": "9.1900"
  },
  "areaServed": [
    { "@type": "City", "name": "Milano" },
    { "@type": "Country", "name": "Italia" }
  ],
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    "opens": "09:00",
    "closes": "20:00"
  },
  "priceRange": "€€",
  "medicalSpecialty": "Psychiatric",
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Servizi di Psicoterapia",
    "itemListElement": [
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Consulenza psicologica individuale" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Consulenza psicologica di coppia" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Consulenza per giovani adulti" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Sedute online" } }
    ]
  }
};

const personJsonLd = {
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Valentina Rita Andolfi",
  "jobTitle": "Psicologa e Psicoterapeuta",
  "honorificPrefix": "Dott.ssa",
  "alumniOf": [
    { "@type": "CollegeOrUniversity", "name": "Università Cattolica del Sacro Cuore di Milano" },
    { "@type": "CollegeOrUniversity", "name": "Tufts University, Boston" },
    { "@type": "CollegeOrUniversity", "name": "Istituto dell'Approccio Centrato sulla Persona (IACP)" }
  ],
  "hasCredential": [
    { "@type": "EducationalOccupationalCredential", "credentialCategory": "Laurea in Psicologia, Empowerment e Benessere" },
    { "@type": "EducationalOccupationalCredential", "credentialCategory": "Dottorato di Ricerca in Psicologia dello Sviluppo e del Benessere" },
    { "@type": "EducationalOccupationalCredential", "credentialCategory": "Specializzazione in Psicoterapia Umanistica" }
  ],
  "knowsAbout": ["psicoterapia", "approccio centrato sulla persona", "psicologia del benessere", "consulenza di coppia", "empowerment"],
  "url": "https://valentina-andolfi.com",
  "workLocation": {
    "@type": "Place",
    "name": "Studio Velasca, Milano"
  }
};

const Index = () => {
  return (
    <div>
      <SEOHead
        title="Valentina Rita Andolfi - Psicologa e Psicoterapeuta a Milano e Online"
        description="Valentina Rita Andolfi, Psicologa e Psicoterapeuta a Milano e Online. Consulenza individuale, di coppia, per giovani adulti. Approccio centrato sulla persona. Primo colloquio gratuito."
        path="/"
        jsonLd={[localBusinessJsonLd, personJsonLd]}
      />
      <Hero />
      <IntroSection />
      <ApproachSection />
      <PersonalitySection />
      <BlogPreview />
    </div>
  );
};

export default Index;
