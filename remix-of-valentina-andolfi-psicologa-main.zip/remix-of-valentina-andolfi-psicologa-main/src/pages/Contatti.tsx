import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { MapPin, Phone, Mail, Clock, Video, Calendar } from 'lucide-react';
import SEOHead from '@/components/SEOHead';
import { z } from 'zod';

const contactSchema = z.object({
  nome: z.string().trim().min(2, { message: "Il nome deve essere di almeno 2 caratteri" }).max(50, { message: "Il nome non può superare i 50 caratteri" }),
  email: z.string().trim().email({ message: "Inserisci un indirizzo email valido" }).max(255, { message: "L'email non può superare i 255 caratteri" }),
  telefono: z.string().trim().min(8, { message: "Inserisci un numero di telefono valido" }).max(20, { message: "Il telefono non può superare i 20 caratteri" }),
  messaggio: z.string().trim().min(10, { message: "Il messaggio deve essere di almeno 10 caratteri" }).max(1000, { message: "Il messaggio non può superare i 1000 caratteri" }),
  preferenza: z.enum(["presenza", "online", "entrambe"], { message: "Seleziona una preferenza valida" })
});

const Contatti = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefono: '',
    messaggio: '',
    preferenza: 'entrambe'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrors({});

    try {
      // Validate form data
      const validatedData = contactSchema.parse(formData);
      
      // Simulate form submission (replace with actual API call)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Messaggio inviato con successo!",
        description: "Ti contatterò entro 24 ore per fissare il nostro primo colloquio gratuito.",
      });
      
      // Reset form
      setFormData({
        nome: '',
        email: '',
        telefono: '',
        messaggio: '',
        preferenza: 'entrambe'
      });
      
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            newErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(newErrors);
      } else {
        toast({
          title: "Errore nell'invio",
          description: "Si è verificato un errore. Riprova più tardi o contattami direttamente.",
          variant: "destructive",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Telefono",
      details: "+39 123 456 7890",
      description: "Chiamami per fissare un appuntamento"
    },
    {
      icon: Mail,
      title: "Email",
      details: "info@valentina-andolfi.com",
      description: "Scrivimi per qualsiasi informazione"
    },
    {
      icon: MapPin,
      title: "Studio Milano",
      details: "Via Roma 123, 20121 Milano",
      description: "Zona Porta Nuova, facilmente raggiungibile"
    },
    {
      icon: Clock,
      title: "Orari",
      details: "Lun-Ven: 9:00-20:00",
      description: "Disponibilità anche serali su appuntamento"
    }
  ];

  return (
    <div className="section-padding">
      <SEOHead
        title="Contatti - Prenota un Colloquio Gratuito | Psicologa Milano"
        description="Contatta la Dott.ssa Valentina Andolfi per prenotare un primo colloquio gratuito. Studio a Milano e sedute online. Disponibilità anche serali."
        path="/contatti"
      />
      <div className="max-w-6xl mx-auto container-padding">
        {/* Page Header */}
        <header className="text-center mb-16 animate-fade-up">
          <h1 className="text-section-title mb-6">Contattami</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Non sei mai stato così vicino al cambiamento. Chiedi a te stesso, cosa desideri fare per te? 
            Ora scrivimi, cosa posso fare io per te?
          </p>
        </header>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="animate-fade-up">
            <CardContent className="p-8">
              <div className="mb-8">
                <h2 className="text-card-title mb-4">Prenota il tuo colloquio gratuito</h2>
                <p className="text-muted-foreground">
                  Il primo colloquio di 30 minuti è gratuito e senza impegno. 
                  Conosciamoci e vediamo insieme come posso aiutarti.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                <div>
                  <Label htmlFor="nome">Nome e Cognome *</Label>
                  <Input
                    id="nome"
                    name="nome"
                    type="text"
                    value={formData.nome}
                    onChange={handleInputChange}
                    className={errors.nome ? "border-destructive" : ""}
                    aria-invalid={!!errors.nome}
                    aria-describedby={errors.nome ? "nome-error" : undefined}
                    required
                    autoComplete="name"
                  />
                  {errors.nome && <p id="nome-error" role="alert" className="text-destructive text-sm mt-1">{errors.nome}</p>}
                </div>

                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className={errors.email ? "border-destructive" : ""}
                    aria-invalid={!!errors.email}
                    aria-describedby={errors.email ? "email-error" : undefined}
                    required
                    autoComplete="email"
                  />
                  {errors.email && <p id="email-error" role="alert" className="text-destructive text-sm mt-1">{errors.email}</p>}
                </div>

                <div>
                  <Label htmlFor="telefono">Telefono *</Label>
                  <Input
                    id="telefono"
                    name="telefono"
                    type="tel"
                    value={formData.telefono}
                    onChange={handleInputChange}
                    className={errors.telefono ? "border-destructive" : ""}
                    aria-invalid={!!errors.telefono}
                    aria-describedby={errors.telefono ? "telefono-error" : undefined}
                    required
                    autoComplete="tel"
                  />
                  {errors.telefono && <p id="telefono-error" role="alert" className="text-destructive text-sm mt-1">{errors.telefono}</p>}
                </div>

                <div>
                  <Label htmlFor="preferenza">Preferenza per gli incontri *</Label>
                  <select
                    id="preferenza"
                    name="preferenza"
                    value={formData.preferenza}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-input rounded-md bg-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                    aria-invalid={!!errors.preferenza}
                    aria-describedby={errors.preferenza ? "preferenza-error" : undefined}
                    required
                  >
                    <option value="presenza">In presenza a Milano</option>
                    <option value="online">Online</option>
                    <option value="entrambe">Entrambe le modalità</option>
                  </select>
                  {errors.preferenza && <p id="preferenza-error" role="alert" className="text-destructive text-sm mt-1">{errors.preferenza}</p>}
                </div>

                <div>
                  <Label htmlFor="messaggio">Messaggio *</Label>
                  <Textarea
                    id="messaggio"
                    name="messaggio"
                    value={formData.messaggio}
                    onChange={handleInputChange}
                    placeholder="Raccontami brevemente il motivo per cui stai cercando supporto psicologico..."
                    className={`min-h-[120px] ${errors.messaggio ? "border-destructive" : ""}`}
                    aria-invalid={!!errors.messaggio}
                    aria-describedby={errors.messaggio ? "messaggio-error" : undefined}
                    required
                  />
                  {errors.messaggio && <p id="messaggio-error" role="alert" className="text-destructive text-sm mt-1">{errors.messaggio}</p>}
                </div>

                <Button 
                  type="submit" 
                  className="w-full btn-primary" 
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Invio in corso..." : "Invia Richiesta"}
                </Button>

                <p className="text-xs text-muted-foreground text-center">
                  Compilando questo modulo accetti che i tuoi dati vengano trattati 
                  secondo la nostra privacy policy per fini di contatto professionale.
                </p>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            {/* Quick Contact */}
            <Card className="animate-fade-up bg-gradient-hero">
              <CardContent className="p-8 text-center">
                <h3 className="text-card-title mb-4">Hai bisogno di aiuto urgente?</h3>
                <p className="text-muted-foreground mb-6">
                  Se stai attraversando un momento di particolare difficoltà, 
                  non esitare a contattarmi direttamente.
                </p>
                <div className="space-y-3">
                  <Button className="w-full btn-primary">
                    <Phone className="mr-2 h-4 w-4" />
                    Chiamami Ora
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Mail className="mr-2 h-4 w-4" />
                    Invia Email
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Contact Info Grid */}
            <div className="grid sm:grid-cols-2 gap-6">
              {contactInfo.map((info, index) => (
                <Card key={index} className="animate-fade-up">
                  <CardContent className="p-6 text-center">
                    <div className="text-primary mb-3">
                      <info.icon size={32} className="mx-auto" />
                    </div>
                    <h4 className="font-semibold mb-2">{info.title}</h4>
                    <p className="font-medium text-foreground mb-1">{info.details}</p>
                    <p className="text-sm text-muted-foreground">{info.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Additional Services */}
            <Card className="animate-fade-up">
              <CardContent className="p-8">
                <h3 className="text-card-title mb-4">Modalità di Consulenza</h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <Video className="text-primary mr-3 mt-1" size={20} />
                    <div>
                      <h4 className="font-semibold">Consulenze Online</h4>
                      <p className="text-sm text-muted-foreground">
                        Stessa qualità professionale, maggiore flessibilità
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <MapPin className="text-primary mr-3 mt-1" size={20} />
                    <div>
                      <h4 className="font-semibold">Studio Milano</h4>
                      <p className="text-sm text-muted-foreground">
                        Ambiente accogliente e riservato nel centro città
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Calendar className="text-primary mr-3 mt-1" size={20} />
                    <div>
                      <h4 className="font-semibold">Orari Flessibili</h4>
                      <p className="text-sm text-muted-foreground">
                        Disponibilità anche serali per venire incontro alle tue esigenze
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contatti;