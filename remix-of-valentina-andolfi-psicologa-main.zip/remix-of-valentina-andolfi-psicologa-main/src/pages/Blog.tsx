import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEOHead from '@/components/SEOHead';

const Blog = () => {
  const articles = [
    {
      id: 1,
      title: "Come gestire l'ansia nella vita quotidiana",
      excerpt: "Strategie pratiche e tecniche evidence-based per affrontare l'ansia e ritrovare serenità nel quotidiano.",
      date: "15 Marzo 2024",
      readTime: "5 min",
      category: "Benessere",
      featured: true
    },
    {
      id: 2,
      title: "L'importanza della comunicazione nelle relazioni",
      excerpt: "Scopri come migliorare la qualità delle tue relazioni attraverso una comunicazione più efficace e autentica.",
      date: "8 Marzo 2024", 
      readTime: "7 min",
      category: "Relazioni"
    },
    {
      id: 3,
      title: "Mindfulness e benessere emotivo",
      excerpt: "Come la pratica della mindfulness può aiutarti a gestire le emozioni e aumentare la consapevolezza di sé.",
      date: "1 Marzo 2024",
      readTime: "6 min",
      category: "Mindfulness"
    },
    {
      id: 4,
      title: "Affrontare i cambiamenti di vita",
      excerpt: "Strategie psicologiche per navigare i momenti di transizione e trasformare le sfide in opportunità di crescita.",
      date: "22 Febbraio 2024",
      readTime: "8 min", 
      category: "Crescita Personale"
    },
    {
      id: 5,
      title: "Il ruolo dell'autostima nel benessere",
      excerpt: "Come sviluppare una sana autostima e riconoscere il proprio valore per vivere una vita più appagante.",
      date: "15 Febbraio 2024",
      readTime: "5 min",
      category: "Crescita Personale"
    },
    {
      id: 6,
      title: "Gestire lo stress lavorativo",
      excerpt: "Tecniche per mantenere l'equilibrio tra vita professionale e personale e prevenire il burnout.",
      date: "8 Febbraio 2024",
      readTime: "6 min",
      category: "Benessere"
    }
  ];

  const categories = ["Tutti", "Benessere", "Relazioni", "Crescita Personale", "Mindfulness"];

  return (
    <div className="section-padding">
      <SEOHead
        title="Blog di Psicologia - Articoli su Benessere e Crescita Personale"
        description="Articoli, riflessioni e strumenti pratici di psicologia per il benessere emotivo, la crescita personale, la gestione dell'ansia e il miglioramento delle relazioni."
        path="/blog"
      />
      <div className="max-w-6xl mx-auto container-padding">
        {/* Page Header */}
        <header className="text-center mb-16 animate-fade-up">
          <h1 className="text-section-title mb-6">Blog</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Articoli, riflessioni e strumenti pratici per il tuo benessere psicologico. 
            Esplora temi di crescita personale, relazioni e salute mentale.
          </p>
        </header>

        {/* Categories Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12 animate-fade-up">
          {categories.map((category) => (
            <Button
              key={category}
              variant="outline"
              className={`rounded-full ${category === "Tutti" ? "bg-primary text-primary-foreground" : ""}`}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Featured Article */}
        {articles.filter(article => article.featured).map((article) => (
          <Card key={article.id} className="mb-16 overflow-hidden animate-fade-up bg-gradient-hero">
            <CardContent className="p-0">
              <div className="grid lg:grid-cols-2 gap-0">
                <div className="bg-primary/10 p-12 flex items-center">
                  <div>
                    <div className="flex items-center gap-4 mb-4">
                      <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                        In Evidenza
                      </span>
                      <span className="bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-medium">
                        {article.category}
                      </span>
                    </div>
                    <h2 className="text-3xl font-bold mb-4">{article.title}</h2>
                    <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                      {article.excerpt}
                    </p>
                    <div className="flex items-center gap-6 text-sm text-muted-foreground mb-6">
                      <div className="flex items-center gap-2">
                        <Calendar size={16} />
                        {article.date}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock size={16} />
                        {article.readTime} di lettura
                      </div>
                    </div>
                    <Button className="btn-primary">
                      Leggi l'articolo
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="bg-gradient-primary min-h-[300px] lg:min-h-[400px]">
                  {/* Placeholder for featured image */}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Articles Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {articles.filter(article => !article.featured).map((article, index) => (
            <Card key={article.id} className="animate-fade-up hover:shadow-xl transition-all duration-300">
              <CardContent className="p-0">
                <div className="bg-gradient-warm h-48"></div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="bg-accent/20 text-accent px-2 py-1 rounded text-sm font-medium">
                      {article.category}
                    </span>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar size={12} />
                        {article.date}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock size={12} />
                        {article.readTime}
                      </div>
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold mb-3 leading-tight">
                    {article.title}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                    {article.excerpt}
                  </p>
                  <Button variant="ghost" className="p-0 h-auto font-medium text-primary hover:text-primary/80">
                    Leggi di più
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Newsletter Subscription */}
        <Card className="bg-primary text-primary-foreground text-center animate-fade-up">
          <CardContent className="p-12">
            <h2 className="text-3xl font-bold mb-4">Rimani aggiornato</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Iscriviti alla newsletter per ricevere i nuovi articoli e consigli pratici 
              per il tuo benessere psicologico direttamente nella tua inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="La tua email"
                className="flex-1 px-4 py-3 rounded-lg text-foreground"
              />
              <Button className="bg-white text-primary hover:bg-white/90 px-8">
                Iscriviti
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Blog;