import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import valentinaPhoto from '@/assets/valentina-photo.png';
import SEOHead from '@/components/SEOHead';

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://valentina-andolfi.com/" },
    { "@type": "ListItem", "position": 2, "name": "Chi Sono", "item": "https://valentina-andolfi.com/chi-sono" }
  ]
};

const ChiSono = () => {
  return (
    <div className="section-padding">
      <SEOHead
        title="Chi Sono - Dott.ssa Valentina Rita Andolfi, Psicologa PhD"
        description="Psicologa, psicoterapeuta e ricercatrice a Milano. Laureata in Psicologia, Dottorato alla Tufts University di Boston, specializzata in Psicoterapia Umanistica. Approccio centrato sulla persona."
        path="/chi-sono"
        jsonLd={breadcrumbJsonLd}
      />
      <div className="max-w-4xl mx-auto container-padding">
        {/* Page Header */}
        <header className="text-center mb-16 animate-fade-up">
          <h1 className="text-section-title mb-4">Chi sono: Psicologa, Psicoterapeuta, Ricercatrice</h1>
          <p className="text-2xl text-muted-foreground max-w-2xl mx-auto italic font-serif">
            La mia passione per la psicologia: al tuo fianco per fiorire
          </p>
        </header>

        {/* Profile Section - La mia storia */}
        <div className="grid md:grid-cols-2 gap-12 items-start mb-16">
          <div className="animate-fade-up">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-primary rounded-2xl transform rotate-2"></div>
              <img
                src={valentinaPhoto}
                alt="Valentina Rita Andolfi"
                className="relative rounded-2xl shadow-xl w-full"
              />
            </div>
          </div>

          <div className="animate-fade-up space-y-6">
            <h2 className="text-card-title text-primary">La mia storia</h2>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Il mio viaggio nella psicologia inizia quando ero poco più che una bambina. Un libro accese la scintilla: raccontava la storia di una bambina come me, ma con una vita ben più dolorosa che era riuscita a cambiare grazie a una persona che credette in lei, la comprese e fu in grado di starle accanto.
              </p>
              <p>
                Questo legame ridiede fiducia e speranza a quella giovane anima che riuscì a crescere, nonostante le intemperie della vita. Una storia di rinascita e speranza che mi fece intuire come <strong>un incontro può cambiare la vita</strong>.
              </p>
              <p>
                Il mio approccio alla psicoterapia si basa proprio sul <strong>potere di un incontro</strong> che riattiva le risorse interiori, rinnova la fiducia e la speranza in sé stessi e negli altri e guarisce le ferite delle relazioni.
              </p>
            </div>
          </div>
        </div>

        {/* La mia formazione */}
        <Card className="animate-fade-up mb-16">
          <CardContent className="p-8">
            <h2 className="text-card-title text-primary mb-2">La mia formazione</h2>
            <p className="text-lg italic text-muted-foreground mb-6">Sapere, saper fare, saper essere</p>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Mi sono laureata in <strong>Psicologia, Empowerment e Benessere</strong> all'Università Cattolica di Milano, nel 2012.
              </p>
              <p>
                Ho conseguito il <strong>dottorato di ricerca in Psicologia dello Sviluppo e del Benessere</strong> in co-tutela con la Tufts University di Boston, nel 2017.
              </p>
              <p>
                Mi sono specializzata in <strong>Psicoterapia Umanistica</strong> presso l'Istituto dell'Approccio Centrato sulla Persona (IACP) di Milano, nel 2020.
              </p>
              <p>
                Il mio percorso formativo è stato un viaggio tra esperienze e conoscenze che hanno ampliato le mie competenze, perfezionato le tecniche e arricchito il mio bagaglio di strumenti per accompagnare le persone a fiorire e a esprimere la loro bellezza, anche nei momenti più difficili.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Leggimi - Pubblicazioni */}
        <Card className="animate-fade-up mb-16">
          <CardContent className="p-8">
            <h2 className="text-card-title text-primary mb-6">Leggimi: alcune mie pubblicazioni e contributi alla ricerca</h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-3">Articoli</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Andolfi, V. R., Di Nuzzo, C., & Antonietti, A. (2017). Opening the mind through the body: The effects of posture on creative processes. <em>Thinking Skills and Creativity</em>, 24, 20-28.</li>
                  <li>• Andolfi, V. R., Valenti, C., Cesa-Bianchi, M., & Cristini, C. (2017). Creatività e tempo libero in età senile. <em>Ricerche di Psicologia</em>.</li>
                  <li>• Andolfi, V. R., Confalonieri, E., Nardo, F., & Traficante, D. (2015). Star bene a scuola: il ruolo delle abilità di letto-scrittura. <em>Psicologia dell'educazione</em>.</li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Strumenti e test</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Elliott C.D., Smith P., Traficante D., Zanetti, M. A., Bonanomi A., Andolfi V. R. (2021). BAS3: British Ability Scales 3. Giunti OS Psychometrics.</li>
                  <li>• Andolfi, V. R., Tay, L., Confalonieri, E., & Traficante, D. (2017). Assessing well-being in children: Italian adaptation of the CIT-Child.</li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Libri</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Gatti, E., Andolfi, V. R., & Antonietti, A. Capire il mondo. LED Edizioni.</li>
                  <li>• Caro diario, mi racconto: il ruolo della narrazione nell'esperienza formativa. In Cristofori, E., et al. (2017). <em>Il laboratorio professionale nella formazione</em>. CEA.</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* La mia mission */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="animate-fade-up">
            <CardContent className="p-8">
              <h3 className="text-card-title text-primary mb-4">Come psicologa</h3>
              <ul className="space-y-3 text-base leading-relaxed">
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Accogliere e dare un significato alle tue emozioni, pensieri e comportamenti.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Accompagnarti a sviluppare le tue capacità di affrontare la vita e di gestire lo stress.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Offrirti supporto professionale per la cura di ansia, stress, depressione, traumi, perdite, cambiamenti di vita.</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="animate-fade-up">
            <CardContent className="p-8">
              <h3 className="text-card-title text-primary mb-4">Come ricercatrice</h3>
              <ul className="space-y-3 text-base leading-relaxed">
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Condurre ricerche scientifiche sulla psicologia del benessere e la psicoterapia.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Diffondere la conoscenza scientifica in materia di salute mentale.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Collaborare con altri professionisti per migliorare la qualità dei servizi di cura.</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="animate-fade-up">
            <CardContent className="p-8">
              <h3 className="text-card-title text-primary mb-4">Come formatrice</h3>
              <ul className="space-y-3 text-base leading-relaxed">
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Percorsi di apprendimento esperienziale che coniugano innovazione e scoperte scientifiche.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Metodologie e strumenti per migliorare il tuo benessere o quello degli altri.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Promuovere l'apprendimento permanente all'interno delle organizzazioni.</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* I miei valori */}
        <Card className="animate-fade-up mb-16">
          <CardContent className="p-8">
            <h2 className="text-card-title text-primary mb-6 text-center">I miei valori</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <h4 className="font-semibold text-lg mb-2">Professionalità</h4>
                <p className="text-muted-foreground text-sm">Agisco con competenza, integrità e rispetto per le persone.</p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-lg mb-2">Empatia</h4>
                <p className="text-muted-foreground text-sm">Mi pongo in ascolto profondo e accolgo le persone con comprensione e senza giudizio.</p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-lg mb-2">Rispetto</h4>
                <p className="text-muted-foreground text-sm">Desidero valorizzare l'unicità di ogni persona e la sua individualità.</p>
              </div>
              <div className="text-center">
                <h4 className="font-semibold text-lg mb-2">Confidenzialità</h4>
                <p className="text-muted-foreground text-sm">Garantisco la privacy e la riservatezza di tutte le informazioni personali.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Approccio terapeutico */}
        <Card className="animate-fade-up mb-16 bg-gradient-hero">
          <CardContent className="p-8">
            <h2 className="text-card-title text-primary mb-6">Il mio approccio terapeutico</h2>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Ogni terapeuta ha un modo di lavorare diverso. Il mio si basa sull'<strong>Approccio Centrato sulla Persona</strong> (ACP), sviluppato da Carl Rogers nel 1942.
              </p>
              <p>
                Al centro del mio lavoro ci sei <strong>tu</strong>: il tuo benessere e la tua crescita personale. Ti aprirò le porte ad un luogo sicuro e accogliente, dove potrai esplorare liberamente pensieri, emozioni e vissuti più profondi.
              </p>
              <p>
                Al tuo fianco, ci sarò io: <strong>autentica, empatica</strong> e pronta ad ascoltare con profonda attenzione la tua storia. Il tuo punto di vista sarà per me una preziosa bussola per orientarci nel tuo mondo interiore.
              </p>
              <p>
                Credo fermamente nelle tue <strong>risorse</strong>: hai dentro di te la forza per affrontare le sfide della vita. Il mio ruolo è accompagnarti in un percorso di auto-esplorazione, aiutandoti a coltivare una maggiore consapevolezza di te stesso e dei tuoi talenti.
              </p>
              <p>
                La <strong>fiducia e il rispetto reciproco</strong> saranno i pilastri della nostra relazione terapeutica. In un clima di assoluto non-giudizio, potrai finalmente esprimerti liberamente, senza timori.
              </p>
              <p className="font-medium italic">
                Nel nostro percorso insieme, <strong>sei tu il capitano della tua nave</strong>. Il viaggio procede alla tua velocità. Prendiamoci il tempo per fare soste quando serve, ammirare il paesaggio e riflettere sui prossimi passi.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Le mie caratteristiche */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="animate-fade-up">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-3">Approccio Centrato sulla Persona</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Nel mio lavoro, mi concentro su di te, mettendoti al centro del processo di cambiamento. Ti aiuto a esplorare il tuo modo di vedere il mondo e di vivere le relazioni con gli altri.
              </p>
            </CardContent>
          </Card>
          <Card className="animate-fade-up">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-3">Empatia e Ascolto Attivo</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Le persone mi affidano le loro storie e io mi impegno a creare uno spazio terapeutico accogliente e privo di giudizi, dove possono sentirsi comprese e libere di esprimersi.
              </p>
            </CardContent>
          </Card>
          <Card className="animate-fade-up">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-3">Ricerca e Formazione Continua</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Il coinvolgimento in eventi e comitati scientifici, unito alle pubblicazioni, evidenzia il mio contributo nel settore della psicologia, unendo la pratica clinica a solide basi scientifiche.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Il mio modo di procedere */}
        <Card className="animate-fade-up mb-16">
          <CardContent className="p-8">
            <h2 className="text-card-title text-primary mb-6">Il mio modo di procedere</h2>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                La consulenza psicologica è un prezioso spazio di libertà e di connessione umana. Durante il nostro primo incontro, condividiamo informazioni chiave come gli obiettivi, i tempi, la frequenza e i costi, per avviare insieme un percorso di trasformazione consapevole e autentico.
              </p>
              <p>
                Questo ci permette di valutare l'inizio di un percorso di consulenza psicologica, in modo libero e consapevole da entrambe le parti e di focalizzarci sul tuo benessere e sui tuoi obiettivi personali.
              </p>
              <p className="text-muted-foreground text-base italic">
                Le prestazioni rese da uno psicologo iscritto all'Albo danno diritto alla detrazione fiscale del 19% (anche in assenza di prescrizione medica).
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Quando puoi rivolgerti a me */}
        <Card className="animate-fade-up mb-16">
          <CardContent className="p-8">
            <h2 className="text-card-title text-primary mb-4">Quando puoi rivolgerti a me?</h2>
            <p className="text-lg text-foreground mb-6">
              Cosa sta succedendo nella tua vita che ti spinge a cercare il supporto di un professionista?
            </p>
            <ul className="space-y-3 text-lg">
              <li className="flex items-start gap-3"><span className="text-primary font-bold mt-1">•</span> Le emozioni che stai vivendo ti bloccano o ti creano sofferenza.</li>
              <li className="flex items-start gap-3"><span className="text-primary font-bold mt-1">•</span> Ti senti solo, come se nessuno potesse capire quello che provi.</li>
              <li className="flex items-start gap-3"><span className="text-primary font-bold mt-1">•</span> Vuoi affrontare un conflitto che ti sembra irrisolvibile.</li>
              <li className="flex items-start gap-3"><span className="text-primary font-bold mt-1">•</span> Senti il bisogno di capire meglio i tuoi bisogni e vuoi attuare un cambiamento.</li>
              <li className="flex items-start gap-3"><span className="text-primary font-bold mt-1">•</span> Sei in difficoltà perché non riesci a superare una perdita o un evento doloroso.</li>
              <li className="flex items-start gap-3"><span className="text-primary font-bold mt-1">•</span> Stai lottando per affrontare delle decisioni e non riesci a orientarti.</li>
              <li className="flex items-start gap-3"><span className="text-primary font-bold mt-1">•</span> Desideri conoscere meglio te stesso, essere consapevole delle tue risorse e trasformare la tua vita in meglio.</li>
            </ul>
            <p className="text-lg mt-6 text-muted-foreground">
              La consulenza psicologica è uno strumento potente per elaborare eventi stressanti e situazioni delicate. Ricevere aiuto professionale significa avere l'opportunità di riflettere su te stesso, cercando il benessere e la serenità interiore.
            </p>
          </CardContent>
        </Card>

        {/* Facciamo un po' di chiarezza */}
        <Card className="animate-fade-up mb-16 bg-gradient-hero">
          <CardContent className="p-8">
            <h2 className="text-card-title text-primary mb-6">Facciamo un po' di chiarezza: chi sono e cosa faccio?</h2>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Sono una <strong>psicoterapeuta</strong>, vale a dire una psicologa professionista, regolarmente iscritta all'Albo, specializzata e abilitata alla pratica della psicoterapia.
              </p>
              <p>
                Il mio obiettivo è supportare le persone a superare difficoltà emotive, relazionali o comportamentali attraverso una cura che si basa sulla parola e su tecniche terapeutiche specifiche. Posso diagnosticare e trattare disturbi o problemi di salute mentale ma non posso prescrivere farmaci, come fanno gli psichiatri.
              </p>
              <p>
                Collaboro con un team di professionisti della salute e psichiatri che lavorano con me presso lo <strong>Studio Velasca</strong>, che è possibile attivare per ottenere una diagnosi o qualora i sintomi siano persistenti e si richieda un trattamento integrato.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <div className="text-center animate-fade-up">
          <Button asChild size="lg" className="btn-primary text-lg px-8 py-4">
            <Link to="/contatti">Sei pronto a iniziare questo viaggio?</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChiSono;
