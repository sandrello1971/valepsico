import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Users, Brain, Sparkles, GraduationCap, Building2, Calendar, Video, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEOHead from '@/components/SEOHead';
import FAQSection, { faqJsonLd } from '@/components/FAQSection';

const breadcrumbJsonLd = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://valentina-andolfi.com/" },
    { "@type": "ListItem", "position": 2, "name": "Servizi", "item": "https://valentina-andolfi.com/servizi" }
  ]
};

const Servizi = () => {
  return (
    <div className="section-padding">
      <SEOHead
        title="Servizi - Consulenza Psicologica Individuale, di Coppia e Online | Milano"
        description="Consulenza psicologica individuale, di coppia, per giovani adulti, gruppi di incontro e percorsi di empowerment. Sedute in studio a Milano e online. Psicoterapeuta Valentina Andolfi."
        path="/servizi"
        jsonLd={[breadcrumbJsonLd, faqJsonLd]}
      />
      <div className="max-w-6xl mx-auto container-padding">
        {/* Page Header */}
        <header className="text-center mb-16 animate-fade-up">
          <h1 className="text-section-title mb-6">Servizi: cosa posso fare per te</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Offro un supporto professionale personalizzato per accompagnarti nel tuo percorso 
            di benessere e crescita personale, sia a Milano che online.
          </p>
        </header>

        {/* Consulenza Individuale */}
        <Card className="animate-fade-up mb-12">
          <CardContent className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <Heart className="text-primary" size={40} />
              <h2 className="text-card-title">Consulenza psicologica individuale</h2>
            </div>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                L'incontro con la psicologa è un <strong>incontro tra persone</strong>. Riconoscere un momento di difficoltà e chiedere aiuto significa essere consapevoli di sé, valutare i propri limiti e sentire la forte necessità di trasformarli in risorse interiori.
              </p>
              <p>
                So bene che affrontare le sfide della vita non è facile. A volte ci si può sentire spaesati, soli e confusi. Provare queste emozioni è umano. Ma devi ricordarti che <strong>non devi farlo da solo</strong>.
              </p>
              <p>
                Spesso pensiamo che chiedere aiuto sia un segno di debolezza, quando in realtà, è un atto di grande <strong>coraggio e amore verso sé stessi</strong>.
              </p>
              <p>Io sono qui per te, per accompagnarti in un viaggio di riscoperta di te stesso e delle tue risorse interiori. Insieme, cammineremo fianco a fianco per:</p>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Accogliere le tue emozioni con gentilezza e imparare a comprenderne il linguaggio profondo.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Affrontare le tue difficoltà con un nuovo sguardo, trovando soluzioni creative e adatte a te.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Ritrovare la tua vitalità e l'entusiasmo per la vita.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Ricostruire la fiducia in te stesso e nelle tue capacità, rafforzando la tua autostima.</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Consulenza di Coppia */}
        <Card className="animate-fade-up mb-12">
          <CardContent className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <Users className="text-primary" size={40} />
              <h2 className="text-card-title">Consulenza psicologica di coppia</h2>
            </div>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Aiuto le coppie a superare le loro difficoltà di comunicazione, a restaurare una capacità di <strong>ascolto reciproco</strong>, a riprendere un <strong>dialogo costruttivo</strong> per riscoprire che le soluzioni, così come i problemi, possono essere condivise.
              </p>
              <p>
                La consulenza psicologica di coppia offre uno spazio sicuro e riservato, dove potete esplorare le vostre aspettative e frustrazioni. Posso aiutarvi a migliorare la comunicazione, a sviluppare una maggiore consapevolezza reciproca.
              </p>
              <p>
                Non è necessario essere "in crisi" per iniziare; al contrario, può essere un'opportunità per conoscervi meglio e costruire modelli comunicativi positivi nel tempo.
              </p>
              <h3 className="text-xl font-semibold mt-6 mb-3">Un percorso psicologico può essere utile quando:</h3>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> La comunicazione tra voi è diventata molto complicata o quasi impossibile.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Le incomprensioni rendono difficile prendere decisioni insieme e vivere in armonia.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Uno o entrambi avete paura di perdere l'altro.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Sperimentate una costante difficoltà nel confronto.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Avete incontrato difficoltà nella sfera dell'intimità.</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Giovani Adulti */}
        <Card className="animate-fade-up mb-12">
          <CardContent className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <Sparkles className="text-primary" size={40} />
              <h2 className="text-card-title">Consulenza psicologica per giovani adulti</h2>
            </div>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Se sei un ragazzo e stai attraversando un momento di vita importante, <strong>ho pensato anche a te!</strong>
              </p>
              <p>Posso offrirti uno spazio in cui:</p>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Affrontare decisioni importanti sul percorso accademico o lavorativo.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Esplorare le tue aspirazioni personali e professionali.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Imparare a gestire relazioni significative e a navigare conflitti.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Affrontare i cambiamenti fisici ed emotivi legati all'età adulta.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Imparare a gestire lo stress quotidiano e le emozioni intense.</li>
              </ul>
              <div className="bg-muted/30 rounded-lg p-6 mt-6">
                <h3 className="text-xl font-semibold mb-3">Come funziona il primo appuntamento?</h3>
                <p className="mb-2">Se sei <strong>maggiorenne</strong>, puoi contattarmi direttamente per un primo appuntamento.</p>
                <p>Se sei <strong>minorenne</strong>, è fondamentale avere il consenso dei genitori. Il primo contatto potrebbe richiedere un incontro con loro. Poi, gli incontri rimarranno uno spazio esclusivamente tuo.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gruppi di Incontro */}
        <Card className="animate-fade-up mb-12">
          <CardContent className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <Brain className="text-primary" size={40} />
              <h2 className="text-card-title">Gruppi di incontro</h2>
            </div>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Se stai cercando un ambiente sicuro e supportivo per esplorare te stesso e le tue relazioni, il <strong>Gruppo di Incontro</strong> è il posto per te.
              </p>
              <p>
                Il Gruppo di Incontro è una forma di terapia di gruppo condotta da una professionista qualificata, che ti offre uno spazio per esplorare i tuoi pensieri, sentimenti e relazioni. Durante le sessioni (circa 90 minuti), avrai l'opportunità di parlare, ascoltare le esperienze degli altri e ricevere supporto dalla comunità del gruppo.
              </p>
              <h3 className="text-xl font-semibold mt-4 mb-3">Cosa puoi ottenere:</h3>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> <strong>Supporto Emotivo</strong>: conforto e comprensione da chi ha sperimentato situazioni simili.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> <strong>Esplorazione Personale</strong>: approfondire la consapevolezza di te stesso.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> <strong>Apprendimento Relazionale</strong>: migliorare le abilità relazionali e comunicative.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> <strong>Crescita Emotiva</strong>: nuove prospettive e strategie per le sfide quotidiane.</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Empowerment e Life Skills */}
        <Card className="animate-fade-up mb-12">
          <CardContent className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <GraduationCap className="text-primary" size={40} />
              <h2 className="text-card-title">Percorsi di empowerment e benessere</h2>
            </div>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Se stai cercando modi efficaci per migliorare le tue abilità e per affrontare le sfide quotidiane con fiducia e resilienza, sei nel posto giusto. I percorsi di potenziamento delle <strong>life skills</strong> offrono un approccio pratico e mirato per sviluppare competenze essenziali per il benessere personale e professionale.
              </p>
              <h3 className="text-xl font-semibold mt-4 mb-3">Durante il percorso potrai:</h3>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Apprendere competenze chiave attraverso moduli strutturati.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Sperimentarle in un ambiente sicuro attraverso simulazioni e attività di gruppo.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Ricevere un feedback personalizzato per migliorare le tue abilità.</li>
                <li className="flex items-start gap-2"><span className="text-primary font-bold">•</span> Sviluppare un piano personale basato sui tuoi obiettivi specifici.</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Formazione e Ricerca */}
        <Card className="animate-fade-up mb-12">
          <CardContent className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <Building2 className="text-primary" size={40} />
              <h2 className="text-card-title">Formazione, progettazione e ricerca</h2>
            </div>
            <div className="space-y-4 text-lg leading-relaxed">
              <p>
                Come psicologa specializzata in formazione, progettazione e ricerca, offro consulenza e servizi professionali ad <strong>aziende, scuole e associazioni</strong>.
              </p>
              <div className="grid md:grid-cols-2 gap-6 mt-6">
                <div>
                  <h3 className="font-semibold text-lg mb-2">Formazione</h3>
                  <ul className="space-y-1 text-base text-muted-foreground">
                    <li>• Seminari e workshop</li>
                    <li>• Corsi di formazione su abilità trasversali</li>
                    <li>• Training su misura</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Progettazione</h3>
                  <ul className="space-y-1 text-base text-muted-foreground">
                    <li>• Interventi psicosociali</li>
                    <li>• Programmi educativi innovativi</li>
                    <li>• Gestione del cambiamento organizzativo</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Ricerca</h3>
                  <ul className="space-y-1 text-base text-muted-foreground">
                    <li>• Studi e indagini empiriche</li>
                    <li>• Valutazione dei bisogni</li>
                    <li>• Valutazione dei programmi</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Consulenza</h3>
                  <ul className="space-y-1 text-base text-muted-foreground">
                    <li>• Consulenza organizzativa</li>
                    <li>• Supporto alle scuole</li>
                    <li>• Progetti europei e internazionali</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Modalities Section */}
        <section className="mb-20">
          <h2 className="text-section-title text-center mb-12 animate-fade-up">
            Come lavoriamo insieme
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="animate-fade-up text-center bg-gradient-hero">
              <CardContent className="p-8">
                <div className="text-primary mb-4">
                  <MapPin size={40} className="mx-auto" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Studio a Milano</h3>
                <p className="text-muted-foreground mb-3">Incontri in presenza nel mio studio professionale</p>
                <p className="text-sm font-medium text-accent">Ambiente accogliente e riservato nel centro di Milano</p>
              </CardContent>
            </Card>
            <Card className="animate-fade-up text-center bg-gradient-hero">
              <CardContent className="p-8">
                <div className="text-primary mb-4">
                  <Video size={40} className="mx-auto" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Sedute Online</h3>
                <p className="text-muted-foreground mb-3">Consulenze tramite videochiamata sicura</p>
                <p className="text-sm font-medium text-accent">Stessa qualità professionale, maggiore flessibilità</p>
              </CardContent>
            </Card>
            <Card className="animate-fade-up text-center bg-gradient-hero">
              <CardContent className="p-8">
                <div className="text-primary mb-4">
                  <Calendar size={40} className="mx-auto" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Orari Flessibili</h3>
                <p className="text-muted-foreground mb-3">Disponibilità anche in orari serali</p>
                <p className="text-sm font-medium text-accent">Adatto alle esigenze lavorative e personali</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* FAQ Section */}
        <FAQSection />

        {/* CTA */}
        <div className="text-center animate-fade-up">
          <Button asChild size="lg" className="btn-primary text-lg px-8 py-4">
            <Link to="/contatti">Contattami per una consulenza</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Servizi;
